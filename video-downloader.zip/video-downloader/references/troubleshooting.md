# Troubleshooting Guide — Video Downloader

## YouTube Rate Limiting (HTTP 429)

### Symptoms
- yt-dlp reports: "Sign in to confirm you're not a bot"
- HTTP 429 errors during download
- Page redirects to CAPTCHA verification
- pytube, Invidious, Piped API all fail simultaneously

### Root Cause
YouTube limits the number of video extraction requests per IP address within a time window. This is triggered by:
- Downloading multiple YouTube videos in quick succession (< 30s apart)
- Making too many API calls (innertube, player API) in a short period
- Using the same IP for scraping and downloading

### Solutions (in order of reliability)

#### 1. Wait and Retry (Most Reliable)
Wait 10-15 minutes for the rate limit to clear, then retry the download. YouTube's rate limits are typically time-based and reset automatically.

```bash
# Simple retry after waiting
"$YTDLP" --ffmpeg-location "$FFMPEG" \
  -f "bestvideo[height<=1080]+bestaudio/best[height<=1080]" \
  --merge-output-format mp4 \
  -o "OUTPUT.mp4" \
  "URL"
```

#### 2. Use Different Player Client
yt-dlp can use different YouTube player clients to bypass some rate limits:

```bash
# iOS client (often works when web is blocked)
"$YTDLP" --ffmpeg-location "$FFMPEG" \
  --extractor-args "youtube:player_client=ios" \
  -f "bestvideo[height<=1080]+bestaudio/best[height<=1080]" \
  --merge-output-format mp4 \
  -o "OUTPUT.mp4" "URL"

# TV client
"$YTDLP" --extractor-args "youtube:player_client=tv" ...

# mweb client (mobile web)
"$YTDLP" --extractor-args "youtube:player_client=mweb" ...
```

#### 3. Use Browser Cookies
```bash
# Chrome cookies
"$YTDLP" --cookies-from-browser chrome ...

# Edge cookies
"$YTDLP" --cookies-from-browser edge ...
```

#### 4. Add Request Delays
```bash
"$YTDLP" --sleep-requests 3 ...
```

### What Does NOT Work
Tested and confirmed ineffective:
- ❌ Free HTTP proxies (proxyscrape.com) — all fail or are blocked
- ❌ Invidious API instances — all return errors or are down
- ❌ Piped API instances — all return errors
- ❌ CORS proxies (allorigins.win, corsproxy.io) — YouTube blocks them
- ❌ jina.ai reader — cannot extract streaming data
- ❌ YouTube innertube API via proxy — still rate limited
- ❌ pytube library — same rate limiting as yt-dlp

## HLS/m3u8 Stream Extraction from SPA Pages

### Problem
Many modern video platforms (e.g., DMG MORI Media) are Single Page Applications (SPAs). The video URL is not in the page HTML — it's loaded dynamically via JavaScript using Media Source Extensions (MSE), producing blob URLs that can't be downloaded directly.

### Solution 1: API Discovery
Check if the platform has a public or semi-public API that returns streaming URLs.

#### Example: DMG MORI Media Platform
1. Inspect the page source or JavaScript bundles to find API endpoints.
2. The DMG MORI API endpoint is: `https://api-event.dmgmori.com/api/v1/assets/{videoId}`
3. Call the API with curl to get streaming URLs:

```bash
curl -s "https://api-event.dmgmori.com/api/v1/assets/VIDEO_ID" | python -c "
import sys, json
d = json.load(sys.stdin)
for url in d.get('streamingUrls', []):
    if 'm3u8' in url:
        print(url)
"
```

4. The API returns `streamingUrls` as a list of strings, including:
   - `https://cdn-event.dmgmori.com/videos/{uuid}/vod_playlist.m3u8` (HLS)
   - `https://cdn-event.dmgmori.com/videos/{uuid}/vod_video.mpd` (DASH)

### Solution 2: Playwright Network Capture
If no API is found, use Playwright to render the page and capture network requests:

```python
from playwright.sync_api import sync_playwright
import time

video_urls = []

def on_request(request):
    url = request.url
    if any(ext in url for ext in ['.m3u8', '.mpd', 'googlevideo.com', '.mp4']):
        if url not in video_urls:
            video_urls.append(url)

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page()
    page.on('request', on_request)
    page.goto('VIDEO_PAGE_URL', wait_until='domcontentloaded')
    time.sleep(5)  # Wait for video to load
    # Try clicking play button
    try:
        page.locator('video, .play-button, .vjs-big-play-button').click(timeout=5000)
        time.sleep(5)
    except:
        pass
    browser.close()

for url in video_urls:
    print(url)
```

### Solution 3: JavaScript Bundle Analysis
If Playwright doesn't capture the URL, analyze the JavaScript bundles loaded by the page:

1. Use curl to get the page HTML.
2. Find `<script src="...">` tags pointing to JS bundles.
3. Download the JS bundles and search for API endpoint patterns (e.g., `api/v1/assets`, `streamingUrls`).

## ffmpeg Missing

### Problem
yt-dlp needs ffmpeg to merge separate audio and video streams (common with YouTube HD videos and HLS streams). Without ffmpeg:
- Video and audio are saved as separate files
- HLS streams may fail to download

### Solution: imageio-ffmpeg
Install `imageio-ffmpeg` which provides a standalone ffmpeg binary:

```bash
"C:/Users/wenjun.qiao/.workbuddy/binaries/python/envs/default/Scripts/python.exe" -m pip install imageio-ffmpeg
```

The ffmpeg binary path:
```
C:\Users\wenjun.qiao\.workbuddy\binaries\python\envs\default\Lib\site-packages\imageio_ffmpeg\binaries\ffmpeg-win-x86_64-v7.1.exe
```

Use it with yt-dlp's `--ffmpeg-location` flag:
```bash
"$YTDLP" --ffmpeg-location "$FFMPEG" ...
```

## Sandbox File Deletion Issues

### Problem
On Windows, the WorkBuddy sandbox may prevent yt-dlp from deleting temporary fragment files (`.f*.webm`, `.f*.mp4`), resulting in "SAFE_DELETE_FAIL_CLOSED" warnings.

### Solution
Use Python with `dangerouslyDisableSandbox: true` to delete temporary files:

```python
import os, glob
folder = r'TARGET_FOLDER'
for f in glob.glob(os.path.join(folder, '*.f*.webm')):
    os.unlink(f)
for f in glob.glob(os.path.join(folder, '*.f*.mp4')):
    if '.f' in os.path.basename(f):
        os.unlink(f)
```

## yt-dlp Format Selection Guide

| Format String | Description |
|--------------|-------------|
| `bestvideo[height<=1080]+bestaudio/best[height<=1080]` | Best 1080p video + best audio, fallback to best 1080p combined |
| `bestvideo[height<=720]+bestaudio/best[height<=720]` | Best 720p video + best audio |
| `best` | Best single file (may be lower quality, no merging needed) |
| (no -f flag) | yt-dlp auto-selects best format |

### Important: HLS Streams
For HLS/m3u8 streams, **do NOT** use `-f best` — HLS streams have separate audio and video tracks that require merging. Use `--merge-output-format mp4` without the `-f` flag.
