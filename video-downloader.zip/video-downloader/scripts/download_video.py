#!/usr/bin/env python3
"""
Video Downloader Script
=======================
Automated video download tool supporting YouTube, HLS/m3u8, and direct URLs.
Uses yt-dlp for extraction and ffmpeg (via imageio-ffmpeg) for merging.

Usage:
    python download_video.py --url <VIDEO_URL> --output <OUTPUT_FOLDER> [--filename <NAME>] [--quality 1080]

Requirements:
    pip install yt-dlp imageio-ffmpeg
"""

import argparse
import os
import sys
import subprocess
import glob
import time
import json
import re

# Tool paths (Windows / WorkBuddy managed environment)
YTDLP = r"C:\Users\wenjun.qiao\.workbuddy\binaries\python\envs\default\Scripts\yt-dlp.exe"
FFMPEG = r"C:\Users\wenjun.qiao\.workbuddy\binaries\python\envs\default\Lib\site-packages\imageio_ffmpeg\binaries\ffmpeg-win-x86_64-v7.1.exe"
PYTHON = r"C:\Users\wenjun.qiao\.workbuddy\binaries\python\envs\default\Scripts\python.exe"


def ensure_tools():
    """Check that yt-dlp and ffmpeg are available, install if missing."""
    if not os.path.exists(YTDLP):
        print("yt-dlp not found, installing...")
        subprocess.run([sys.executable, "-m", "pip", "install", "yt-dlp"], check=True)
    if not os.path.exists(FFMPEG):
        print("ffmpeg not found, installing imageio-ffmpeg...")
        subprocess.run([sys.executable, "-m", "pip", "install", "imageio-ffmpeg"], check=True)


def get_next_filename(folder, basename="video", ext="mp4"):
    """Get the next sequential filename in the folder (01_video.mp4, 02_video.mp4, ...)."""
    existing = []
    for f in os.listdir(folder):
        match = re.match(r'^(\d+)_' + re.escape(basename) + r'\.' + ext + '$', f)
        if match:
            existing.append(int(match.group(1)))
    if not existing:
        return f"01_{basename}.{ext}"
    next_num = max(existing) + 1
    return f"{next_num:02d}_{basename}.{ext}"


def download_youtube(url, output_folder, filename, quality=1080, max_retries=3):
    """Download a YouTube video in HD quality."""
    if not filename:
        filename = get_next_filename(output_folder)
    elif not filename.endswith('.mp4'):
        filename += '.mp4'

    output_path = os.path.join(output_folder, filename)
    format_str = f"bestvideo[height<={quality}]+bestaudio/best[height<={quality}]"

    for attempt in range(1, max_retries + 1):
        print(f"\n=== Attempt {attempt}/{max_retries} ===")
        cmd = [
            YTDLP,
            "--ffmpeg-location", FFMPEG,
            "-f", format_str,
            "--merge-output-format", "mp4",
            "-o", output_path,
            "--no-cache-dir",
        ]

        # Alternate player clients on retries to bypass rate limiting
        if attempt == 2:
            cmd += ["--extractor-args", "youtube:player_client=ios"]
        elif attempt == 3:
            cmd += ["--extractor-args", "youtube:player_client=tv"]
            cmd += ["--sleep-requests", "3"]

        cmd.append(url)

        print(f"Command: {' '.join(cmd)}")
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)

        if result.returncode == 0:
            print(f"\n✅ Download successful: {output_path}")
            clean_temp_files(output_folder, filename)
            verify_video(output_path)
            return output_path

        # Check for rate limiting
        stderr = result.stderr + result.stdout
        if "429" in stderr or "Too Many Requests" in stderr or "Sign in to confirm" in stderr:
            wait_time = 120 * attempt  # 2 min, 4 min, 6 min
            print(f"\n⚠️  Rate limited (HTTP 429). Waiting {wait_time}s before retry...")
            print(f"   This is common when downloading multiple YouTube videos quickly.")
            time.sleep(wait_time)
            continue
        elif "403" in stderr or "Forbidden" in stderr:
            print(f"\n⚠️  HTTP 403 Forbidden. Retrying in 30s...")
            time.sleep(30)
            continue
        else:
            print(f"\n❌ Download failed (exit code {result.returncode})")
            print(f"Stdout: {result.stdout[-500:]}")
            print(f"Stderr: {result.stderr[-500:]}")
            # Try with simpler format as fallback
            if attempt < max_retries:
                print("Retrying with simpler format...")
                cmd_simple = [
                    YTDLP,
                    "--ffmpeg-location", FFMPEG,
                    "-f", "best",
                    "--merge-output-format", "mp4",
                    "-o", output_path,
                    url
                ]
                result2 = subprocess.run(cmd_simple, capture_output=True, text=True, timeout=600)
                if result2.returncode == 0:
                    print(f"\n✅ Download successful (fallback): {output_path}")
                    clean_temp_files(output_folder, filename)
                    verify_video(output_path)
                    return output_path
                time.sleep(30)

    print(f"\n❌ All {max_retries} attempts failed.")
    return None


def download_hls(url, output_folder, filename):
    """Download an HLS/m3u8 streaming video."""
    if not filename:
        filename = get_next_filename(output_folder)
    elif not filename.endswith('.mp4'):
        filename += '.mp4'

    output_path = os.path.join(output_folder, filename)

    cmd = [
        YTDLP,
        "--ffmpeg-location", FFMPEG,
        "--merge-output-format", "mp4",
        "-o", output_path,
        url
    ]

    print(f"Downloading HLS stream: {url}")
    print(f"Output: {output_path}")
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)

    if result.returncode == 0:
        print(f"\n✅ Download successful: {output_path}")
        clean_temp_files(output_folder, filename)
        verify_video(output_path)
        return output_path
    else:
        print(f"\n❌ Download failed (exit code {result.returncode})")
        print(f"Stdout: {result.stdout[-500:]}")
        print(f"Stderr: {result.stderr[-500:]}")
        return None


def clean_temp_files(folder, final_filename):
    """Remove temporary fragment files left by yt-dlp."""
    cleaned = 0
    for f in os.listdir(folder):
        # Remove .f*.webm and .f*.mp4 fragment files
        if f.endswith('.webm') and '.f' in f:
            try:
                os.unlink(os.path.join(folder, f))
                cleaned += 1
            except:
                pass
        elif f.endswith('.mp4') and '.f' in f and f != final_filename:
            try:
                os.unlink(os.path.join(folder, f))
                cleaned += 1
            except:
                pass
        # Remove .part and .ytdl files
        elif f.endswith('.part') or f.endswith('.ytdl'):
            try:
                os.unlink(os.path.join(folder, f))
                cleaned += 1
            except:
                pass
    if cleaned:
        print(f"🧹 Cleaned {cleaned} temporary file(s).")


def verify_video(video_path):
    """Verify video metadata (resolution, duration, codec)."""
    if not os.path.exists(video_path):
        print("⚠️  Video file not found for verification.")
        return

    size_mb = os.path.getsize(video_path) / (1024 * 1024)
    print(f"📁 File size: {size_mb:.1f} MB")

    try:
        cmd = [FFMPEG, "-i", video_path]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        output = result.stderr

        # Extract duration
        duration_match = re.search(r'Duration:\s*(\d+:\d+:\d+\.\d+)', output)
        if duration_match:
            print(f"⏱️  Duration: {duration_match.group(1)}")

        # Extract video stream info
        video_match = re.search(r'Video:\s*(\w+).*?(\d+x\d+)', output)
        if video_match:
            codec = video_match.group(1)
            resolution = video_match.group(2)
            print(f"🎬 Video: {codec}, {resolution}")

            # Check if HD
            height = int(resolution.split('x')[1])
            if height >= 1080:
                print(f"✅ Quality: Full HD (1080p)")
            elif height >= 720:
                print(f"✅ Quality: HD (720p)")
            else:
                print(f"⚠️  Quality: {height}p (below HD)")

        # Extract audio stream info
        audio_match = re.search(r'Audio:\s*(\w+)', output)
        if audio_match:
            print(f"🔊 Audio: {audio_match.group(1)}")

    except Exception as e:
        print(f"⚠️  Could not verify video metadata: {e}")


def extract_m3u8_from_api(api_url):
    """
    Fetch m3u8 URL from a media platform API.
    Example: DMG MORI API returns streamingUrls array.
    """
    import urllib.request
    try:
        with urllib.request.urlopen(api_url, timeout=15) as resp:
            data = json.loads(resp.read().decode('utf-8'))

        # Try common response formats
        if isinstance(data, dict):
            # Format 1: streamingUrls is a list of strings
            urls = data.get('streamingUrls', [])
            if urls and isinstance(urls[0], str):
                for url in urls:
                    if 'm3u8' in url:
                        return url

            # Format 2: streamingUrls is a list of objects with 'url' field
            for item in urls:
                if isinstance(item, dict):
                    url = item.get('url', '')
                    if 'm3u8' in url:
                        return url

        return None
    except Exception as e:
        print(f"API request failed: {e}")
        return None


def main():
    parser = argparse.ArgumentParser(description="Download videos from YouTube, HLS streams, or direct URLs.")
    parser.add_argument("--url", required=True, help="Video URL (YouTube, m3u8, or direct MP4)")
    parser.add_argument("--output", required=True, help="Output folder path")
    parser.add_argument("--filename", default=None, help="Output filename (without extension). Auto-numbered if omitted.")
    parser.add_argument("--quality", type=int, default=1080, help="Max video height (default: 1080)")
    parser.add_argument("--max-retries", type=int, default=3, help="Max download retries (default: 3)")
    parser.add_argument("--api-url", default=None, help="API URL to fetch m3u8 streaming URL (for SPA pages)")

    args = parser.parse_args()

    # Ensure tools are installed
    ensure_tools()

    # Create output folder if needed
    os.makedirs(args.output, exist_ok=True)

    # Determine source type
    url = args.url

    # If API URL is provided, fetch the actual streaming URL first
    if args.api_url:
        print(f"Fetching streaming URL from API: {args.api_url}")
        m3u8_url = extract_m3u8_from_api(args.api_url)
        if m3u8_url:
            print(f"Found m3u8 URL: {m3u8_url}")
            url = m3u8_url
        else:
            print("❌ Could not extract m3u8 URL from API response.")
            sys.exit(1)

    # Download based on source type
    if 'youtube.com' in url or 'youtu.be' in url:
        result = download_youtube(url, args.output, args.filename, args.quality, args.max_retries)
    elif '.m3u8' in url:
        result = download_hls(url, args.output, args.filename)
    else:
        # Try yt-dlp for any URL (it supports many platforms)
        result = download_youtube(url, args.output, args.filename, args.quality, args.max_retries)

    if result:
        print(f"\n🎉 Done! Video saved to: {result}")
    else:
        print(f"\n❌ Failed to download video.")
        sys.exit(1)


if __name__ == "__main__":
    main()
