---
name: video-downloader
description: "Download videos from YouTube, HLS/m3u8 streaming platforms, and direct URLs to a user-specified folder in HD quality. This skill should be used when the user asks to download, save, or fetch a video from a web page or URL to their local machine. Triggers include: download this video, save video from URL, download YouTube video, download streaming video, 下载视频, 下载网页视频, 保存视频到本地. Handles rate limiting, audio/video merging, and quality selection automatically."
agent_created: true
---

# Video Downloader

## Overview

Download videos from various sources (YouTube, HLS/m3u8 streaming platforms, direct URLs) to a user-specified local folder in the highest available quality (up to 1080p). Uses `yt-dlp` for extraction and `ffmpeg` (via `imageio-ffmpeg`) for audio/video merging. Handles rate limiting, retries, and temporary file cleanup automatically.

## Tool Paths (Windows)

These paths are specific to the WorkBuddy managed Python environment:

- **yt-dlp**: `C:/Users/wenjun.qiao/.workbuddy/binaries/python/envs/default/Scripts/yt-dlp.exe`
- **Python**: `C:/Users/wenjun.qiao/.workbuddy/binaries/python/envs/default/Scripts/python.exe`
- **ffmpeg**: `C:/Users/wenjun.qiao/.workbuddy/binaries/python/envs/default/Lib/site-packages/imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe`

If any tool is missing, install it:
```bash
# Install yt-dlp and imageio-ffmpeg into the managed venv
"C:/Users/wenjun.qiao/.workbuddy/binaries/python/envs/default/Scripts/python.exe" -m pip install yt-dlp imageio-ffmpeg
```

## Workflow

### Step 1: Identify the Video Source

Determine the video source type from the user's URL:

| Source Type | URL Pattern | Download Method |
|-------------|------------|-----------------|
| YouTube | `youtube.com/watch?v=`, `youtu.be/` | yt-dlp with format selection |
| HLS/m3u8 | URL ends with `.m3u8` or contains `/vod_playlist.m3u8` | yt-dlp with `--merge-output-format mp4` |
| Direct MP4 | URL ends with `.mp4` | yt-dlp or direct download |
| Embedded/SPA | Web page with video but no direct URL | Use Playwright to capture network requests, then extract streaming URL |

### Step 2: Confirm Target Folder

- Ask the user for the target folder if not specified.
- Create the folder if it does not exist.
- Check existing files to determine the next sequential filename (e.g., `01_video.mp4`, `02_video.mp4`).

### Step 3: Download the Video

Use `scripts/download_video.py` for automated download, or run yt-dlp directly:

#### YouTube Videos

```bash
YTDLP="C:/Users/wenjun.qiao/.workbuddy/binaries/python/envs/default/Scripts/yt-dlp.exe"
FFMPEG="C:/Users/wenjun.qiao/.workbuddy/binaries/python/envs/default/Lib/site-packages/imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe"

"$YTDLP" --ffmpeg-location "$FFMPEG" \
  -f "bestvideo[height<=1080]+bestaudio/best[height<=1080]" \
  --merge-output-format mp4 \
  -o "TARGET_FOLDER/FILENAME.%(ext)s" \
  "VIDEO_URL"
```

#### HLS/m3u8 Streaming Videos

```bash
"$YTDLP" --ffmpeg-location "$FFMPEG" \
  --merge-output-format mp4 \
  -o "TARGET_FOLDER/FILENAME.%(ext)s" \
  "M3U8_URL"
```

#### Extracting m3u8 URL from SPA Pages

For pages that load video dynamically (e.g., DMG MORI Media platform), the m3u8 URL is not in the page source. Use one of these methods:

1. **API Discovery**: Check if the platform has a public API (e.g., `https://api-event.dmgmori.com/api/v1/assets/{videoId}` returns `streamingUrls`).
2. **Playwright Network Capture**: Use Playwright to render the page and capture network requests containing `googlevideo.com`, `.m3u8`, or `.mpd` URLs.

See `references/troubleshooting.md` for detailed SPA video extraction methods.

### Step 4: Handle Rate Limiting (HTTP 429)

YouTube may return HTTP 429 (Too Many Requests) when downloading multiple videos in quick succession. Symptoms:
- yt-dlp reports "Sign in to confirm you're not a bot"
- HTTP 429 errors during download
- Page redirects to CAPTCHA

**Handling strategy** (in order of preference):

1. **Wait and retry**: Wait 10-15 minutes for the rate limit to clear, then retry. This is the most reliable method.
2. **Use different player client**: Add `--extractor-args "youtube:player_client=ios"` or `player_client=tv` or `player_client=mweb`.
3. **Use browser cookies**: Add `--cookies-from-browser chrome` or `--cookies-from-browser edge`.
4. **Add delays**: Add `--sleep-requests 3` between requests.

**Do NOT** try Invidious, Piped API, CORS proxies, or free HTTP proxies — these have been tested and consistently fail. Just wait for the rate limit to clear.

### Step 5: Clean Up Temporary Files

After download, yt-dlp may leave temporary `.webm` and `.f*.mp4` fragment files if the sandbox prevents deletion. Clean them with Python:

```python
import os, glob
folder = r'TARGET_FOLDER'
for f in glob.glob(os.path.join(folder, '*.f*.webm')):
    os.unlink(f)
for f in glob.glob(os.path.join(folder, '*.f*.mp4')):
    if '.f' in os.path.basename(f):
        os.unlink(f)
```

Use `dangerouslyDisableSandbox: true` if the sandbox blocks file deletion.

### Step 6: Verify Video Quality

Use ffmpeg to verify the downloaded video's resolution and duration:

```bash
FFMPEG="C:/Users/wenjun.qiao/.workbuddy/binaries/python/envs/default/Lib/site-packages/imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe"
"$FFMPEG" -i "VIDEO_PATH" 2>&1 | grep -E "Duration|Stream|Video|Audio"
```

Confirm the video is at least 720p (preferably 1080p). If the quality is too low (e.g., 360p), delete and re-download with explicit format selection.

## Best Practices

- **Filename numbering**: Use sequential numbering (`01_`, `02_`, etc.) based on existing files in the target folder.
- **Quality priority**: Always request `bestvideo[height<=1080]+bestaudio/best[height<=1080]` for HD quality.
- **Rate limit awareness**: If downloading multiple YouTube videos, space requests by at least 30 seconds to avoid triggering rate limits.
- **Merge format**: Always specify `--merge-output-format mp4` to ensure compatibility.
- **No ffmpeg flag**: Never use `-f best` for HLS streams — they have separate audio/video tracks that require merging.
